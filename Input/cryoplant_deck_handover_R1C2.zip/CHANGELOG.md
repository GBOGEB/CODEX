# Changelog

## 2025-10-31 R1C2
- Initialized deck scaffold
- Added Slides.md (10 slides)
- Added scripts for PPTX build and Pandoc integration stubs
