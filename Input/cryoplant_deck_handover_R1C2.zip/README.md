# Cryoplant Deck Handover (Digital Twin: Markdown-first)

**Project:** Cryoplant · **Version:** R1C2 · **Date:** 2025-10-31

This package is a self-contained handover for a Markdown → PPTX/PDF workflow with Git versioning.
Markdown is the *digital twin master*. PPTX/PDF/Docx are generated artifacts.

## Folder Map
```
cryoplant_deck/
  slides/
    Slides.md                # Master Markdown (source of truth)
  scripts/
    make_pptx.py             # Build PPTX from Markdown (python-pptx)
    make_pdf.sh              # Pandoc landscape PDF (1 slide per page)
    make_all.sh              # Convenience: PPTX + PDF (if pandoc present)
  templates/
    master.pptx              # (Optional) Custom master theme to use
  out/
    slides.pptx              # Generated
    slides.pdf               # Generated if pandoc installed
  VERSION
  CHANGELOG.md
  README.md
  .gitignore
```

## Quick Start
1. **(Optional)** Activate venv and install python-pptx:
   ```bash
   python -m venv .venv && source .venv/bin/activate
   pip install python-pptx
   ```
2. **Build PPTX**:
   ```bash
   python scripts/make_pptx.py
   ```
3. **Build PDF (landscape, one slide per page) with Pandoc**:
   ```bash
   ./scripts/make_pdf.sh
   ```
   > Requires: `pandoc` (+ `wkhtmltopdf` or LaTeX engine). Slides use A4 landscape.

## Git / GitHub Flow
- Initialize and commit:
  ```bash
  git init
  git checkout -b feature/mtbf-deck-R1C2
  git add .
  git commit -m "feat(deck): initialize R1C2 scaffold"
  ```
- Iterate:
  ```bash
  git commit -am "chore(slides): refine S6 N-1 table; add RTM refs"
  ```
- Tag releases:
  ```bash
  git tag -a R1C2 -m "Cryoplant deck R1C2"
  ```
- Push to GitHub (GBOGEB/KEB orgs as needed):
  ```bash
  git remote add origin <your-remote-url>
  git push -u origin feature/mtbf-deck-R1C2 --tags
  ```

## Diffing & Patch Notes
- Use standard Git diffs for `slides/Slides.md`.
- Maintain `CHANGELOG.md` with Keep-a-Changelog style.
- For RTM alignment, include "Ref: RTM-XXXX" in commit messages when changing requirement-linked content.

## Jupyter / JetBrains / PyCharm
- Open a Jupyter notebook to programmatically update tables and regenerate PPTX.
- PyCharm/IntelliJ/VSCode: add pre-commit hook to run `make_pptx.py` and warn if `Slides.md` not staged.

## MCP / Copilot Notes
- This repo is compatible with GitHub Copilot / MCP agents. Prompts can target `slides/Slides.md` region edits.
- Use a PR template that requires RTM references for any change.

## Custom Master Theme
- Place a PowerPoint theme at `templates/master.pptx`. The builder will use it if present (fallback: default theme).

## Naming / Versioning
- Semantic-like document versions (R<major>C<minor>): e.g., R1C2.
- File outputs: `out/slides.pptx`, `out/slides.pdf` (include version in filename if desired).

## Inputs → Outputs Summary
- **Input:** `slides/Slides.md` (master)
- **Outputs:** PPTX, PDF (landscape), optionally DOCX via Pandoc.

## License
Internal use.
