---
title: "Cryoplant MTBF and System Design Deck"
version: "R1C2"
date: "2025-10-31"
project: "Cryoplant"
slug: "cryoplant-mtbf-r1c2"
---

# Global slide styling and structure
- **Title style:** H1 short, action-oriented.
- **H2:** section headings within slides.
- **Lists:** bullets; use ordered lists for RTM/sections.
- **Figures/Tables:** captions “Figure X-Y”, “Table X-Y” (X=slide, Y=per-slide seq).
- **Cross-refs:** “Ref: Addendum II RTM-XX”.
- **Footer:** “Project: Cryoplant | Version: R1C2 | Date: 2025-10-31”
- **Slide numbers:** match plan section.

## Slide 1 — Objective and Design Target (S1)
**Title:** Cryoplant Objective and Design Flow Targets

**Key Points**
- Design flow range: 330–350 g/s helium to QPLANT under normal operation. *(Ref: Addendum II RTM-FLOW-01)*
- Frequency policy: 60 Hz nominal; 72 Hz for peak/short-duration transient coverage. *(Ref: RTM-CTL-02)*
- Supply pressure to be maintained per interface spec; turbine speed reduction is secondary mitigation. *(Ref: RTM-INTF-05)*

**Table 1-1: Design Targets and Limits**
| Parameter | Nominal | Peak | Limit | Reference |
|---|---:|---:|---:|---|
| Total flow (g/s) | 340 | 350 | 360 | RTM-FLOW-01 |
| Supply pressure (bar) | As per HEX interface | +2% transient | ±5% | RTM-INTF-01 |
| VFD frequency (Hz) | 60 | 72 | 72 (max) | RTM-CTL-02 |

**Figure 1-1:** Gauge icon chart showing “Nominal 60 Hz” (green) and “Peak 72 Hz” (amber).

## Slide 2 — Source Documents and RTM Canonicalization (S2)
**Title:** Canonical Sources, RTM Ownership, and Traceability

**Bullets**
- Addendum II is the canonical source of RTM numbers and requirements.
- All secondary docs must align: CONTRACTOR_QUICK_GUIDE, COMPREHENSIVE_TECHNICAL_REPORT, WCS_HPC_Performance, ATS(ACR) NFS.
- Change control: Any update propagates to RTM index and interfaces.

**Table 2-1: RTM Ownership Map**
| Area | Canonical RTM ID Range | Secondary Doc(s) | Status |
|---|---|---|---|
| Flow/Pressure | RTM-FLOW-* | HEX Interface, CTR | Align |
| Reliability/MTBF | RTM-REL-* | CTR, WCS/HPC | Pending insert |
| Controls/VFD | RTM-CTL-* | CTR, ATS(ACR) | Align |

*Ref: Addendum II RTM-INDEX-00*

## Slide 3 — System Capacity and Cooldown Envelope (S3)
**Title:** Cooldown and Capacity Envelope vs QPLANT

**Bullets**
- Cooldown duration achievable: 1.2–1.5 days. *(Ref: RTM-CD-01)*
- Peak equivalent power within QPLANT capacity; margin acceptable for transients. *(Ref: RTM-CAP-02)*
- Flow stability prioritized during cooldown ramps; pressure hold bands per interface.

**Figure 3-1:** Time-series plot: flow (g/s) and power (kW) over 36 hours highlighting peak windows.

**Table 3-1: Envelope Constraints**
| Constraint | Value | Bound | Reference |
|---|---|---|---|
| Cooldown time | 28–36 h | ≤ 48 h | RTM-CD-01 |
| Peak equiv. power | TBD | ≤ QPLANT limit | RTM-CAP-02 |

## Slide 4 — Compressor Options Summary (S4)
**Title:** Compressor Options: FSD 475, FSD 575, HSD Combi

**Bullets**
- FSD 475 @72 Hz ≈ 96 g/s. *(Ref: WCS_HPC_Performance)*
- FSD 575 @72 Hz ≈ 112.5 g/s.
- HSD Combi nominal solution delivers ≈ 350 g/s (4× ≈87.5 g/s @72 Hz or equivalent arrangement).
- 60 Hz long-run; 72 Hz for peak.

**Table 4-1: Option Comparison**
| Option | Units | Flow @60 Hz | Flow @72 Hz | N-1 @60 Hz | N-1 @72 Hz |
|---|---:|---:|---:|---:|---:|
| FSD 475 | TBD | TBD | 96 | TBD | TBD |
| FSD 575 | TBD | TBD | 112.5 | TBD | TBD |
| HSD Combi | 4 | ~87.5 each | ~87.5 each | Meets | Meets |

**Figure 4-1:** Stacked bar chart vs 330–350 g/s target.

## Slide 5 — VFD Frequency Strategy and Control (S5)
**Title:** Frequency Strategy: Reliability vs Peak Performance

**Bullets**
- Policy: 60 Hz nominal for life/efficiency; 72 Hz limited duty. *(Ref: RTM-CTL-02, RTM-REL-03)*
- Control loop priorities: Maintain supply pressure window; modulate speed as secondary.
- Thermal/mechanical derating rules at 72 Hz (duty cycle, temperature thresholds).

**Table 5-1: Duty Cycle Constraints @72 Hz**
| Parameter | Limit | Rationale | Ref |
|---|---|---|---|
| Max continuous time | ≤ 2 h | Bearing life | RTM-REL-04 |
| Cooldown post-peak | ≥ 1 h @ ≤ 60 Hz | Thermal soak | RTM-REL-04 |

**Figure 5-1:** Control priority block diagram.

## Slide 6 — N-1 Resilience and Failure Scenarios (S6)
**Title:** N-1 Coverage vs Design Point

**Bullets**
- Requirement: Maintain ≥ 330 g/s under single-unit outage if configured per selected option. *(Ref: RTM-REL-02)*
- Findings: FSD 475/575 sets may meet nominal but can fall short N-1 unless oversizing; HSD combi designed to hit target directly.

**Table 6-1: N-1 Scenario Results**
| Configuration | Nominal (g/s) | N-1 (g/s) | Meets 330 g/s? | Notes |
|---|---:|---:|:---:|---|
| FSD 475 | TBD | TBD | No | Requires oversizing |
| HSD Combi | 350 | ~330 | Yes | Meets design target |

**Figure 6-1:** Waterfall from nominal to N-1 vs target band.

## Slide 7 — Interfaces: HEX, ATS(ACR), NFS, Controls (S7)
**Title:** Interfaces and Responsibilities

**Bullets**
- HEX interface: pressure bands, temperature windows, flow stability criteria. *(Ref: NA.AA-IDD002)*
- ATS(ACR)/NFS responsibilities and handshakes; alarms and setpoint ownership. *(Ref: ATS(ACR) doc)*
- Control modes: normal/peak/fault; trip logic thresholds.

**Table 7-1: Interface Requirements Summary**
| Signal/Setpoint | Owner | Normal Range | Fault Threshold | RTM Ref |
|---|---|---|---|---|
| Pressure | HEX | TBD | TBD | RTM-INTF-05 |
| Temp | HEX | TBD | TBD | RTM-INTF-06 |
| Alarm | NFS | TBD | TBD | RTM-CTL-03 |

**Figure 7-1:** Interface topology diagram.

## Slide 8 — Reliability and MTBF Requirements (Overview) (S8)
**Title:** MTBF Framework and Targets

**Bullets**
- Tiered MTBF: unit-level compressors, package (skid), and system-level mission MTBF. *(Ref: Addendum II RTM-REL-*)*
- Duty assumptions: 60 Hz baseline usage; 72 Hz derates applied to life consumption.
- Failure modes considered: bearings, seals, VFD, controls sensors, cooling auxiliaries.

**Table 8-1: MTBF Targets by Level**
| Asset Level | Target MTBF (hours) | Mission Profile Basis | Ref |
|---|---:|---|---|
| Compressor (Kaeser class) | 40,000–60,000 | 60 Hz duty | RTM-REL-10 |
| VFD module | 100,000 | Ambient ≤ X°C | RTM-REL-11 |
| System (loss of flow ≥ 10%) | 10,000 | N-1 resilient | RTM-REL-12 |

**Figure 8-1:** Reliability block diagram (series-parallel representing N units with N-1 redundancy).

## Slide 9 — MTBF Data: Calculation Basis and R1C2 Content (S9)
**Title:** MTBF Detail: Data, Derating, and R1C2 Tables

**Subsections**
- **Data Sources and Assumptions:** Vendor data for FSD 475/575/HSD combi where available; generic compressor/VFD failure rates when vendor MTBF not given; temperature & vibration derating at 72 Hz duty fractions.
- **Derating Model:** Life consumption per hour at 72 Hz = k × life@60 Hz; use factor e.g., 1.3–1.6 unless vendor specifies. *(Ref: RTM-REL-13)*
- **R1C2 Deliverables:** MTBF tables for component and system, plus reliability diagram.

**Table 9-1: Component MTBF and Derating**
| Component | Base MTBF@60 Hz (h) | Duty @72 Hz (%) | Derate Factor | Effective MTBF (h) | Ref |
|---|---:|---:|---:|---:|---|
| Compressor | TBD | TBD | TBD | TBD | RTM-REL-10 |
| VFD | TBD | TBD | TBD | TBD | RTM-REL-11 |

**Table 9-2: System MTBF Scenarios**
| Config | Components in Parallel | N-1? | Mission MTBF (h) | Meets Req? | Notes |
|---|---:|:---:|---:|:---:|---|
| 4× HSD combi | 4 | Yes | TBD | TBD | TBD |

**Figure 9-1:** Fault tree example for “Loss of flow ≥ 10%”.

## Slide 10 — Energy, Efficiency, and Operations (S10)
**Title:** Energy Optimization and OPEX Implications

**Bullets**
- 60 Hz nominal operation improves life and energy; 72 Hz usage tracked and minimized.
- Load-sharing strategy to keep units in highest efficiency island while meeting flow band.
- Power-quality and harmonics within limits; VFD filters per spec. *(Ref: RTM-EN-01)*

**Table 10-1: Efficiency vs Frequency**
| Frequency | kW per g/s | Specific Power Trend | Notes |
|---|---:|---|---|
| 60 Hz | TBD | Optimal | Baseline |
| 72 Hz | TBD | +Δ | Transient use only |

**Figure 10-1:** Heat map of efficiency vs load and frequency.

*Footer (all slides):* Project: Cryoplant | Version: R1C2 | Date: 2025-10-31
