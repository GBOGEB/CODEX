#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python scripts/make_pptx.py
./scripts/make_pdf.sh || true
