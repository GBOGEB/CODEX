#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
in="slides/Slides.md"
out="out/slides.pdf"
# A4 landscape, 1 slide per page-ish via default PDF (Pandoc can also target reveal.js/beamer)
if ! command -v pandoc >/dev/null 2>&1; then
  echo "Pandoc not found. Please install pandoc to build PDF."
  exit 1
fi
pandoc "$in" -o "$out" \
  -V geometry:margin=1in \
  -V geometry:landscape \
  --pdf-engine=xelatex
echo "Wrote $out"
