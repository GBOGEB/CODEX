
import os, re, sys, datetime
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor

BASE = os.path.dirname(os.path.dirname(__file__))
MD = os.path.join(BASE, "slides", "Slides.md")
OUT = os.path.join(BASE, "out", "slides.pptx")
TEMPLATE = os.path.join(BASE, "templates", "master.pptx")

def load_md(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def split_slides(md):
    # Split on "## Slide " headers
    blocks = re.split(r"(?m)^##\s+Slide\s+\d+\s+.*$", md)
    headers = re.findall(r"(?m)^##\s+Slide\s+(\d+)\s+—\s+(.*)$", md)
    # First block is preamble; drop it
    slides = []
    for i, h in enumerate(headers):
        num, title = h
        body = blocks[i+1].strip()
        slides.append((int(num), title.strip(), body))
    return slides

def md_tables(md_block):
    # Find all markdown tables; return list of (caption, header, rows)
    tables = []
    # Caption line "**Table X-Y: Name**" optional
    pattern = re.compile(r"\*\*Table\s+([0-9\-]+):\s*(.*?)\*\*[\r\n]+((?:\|.*\n)+)", re.S)
    for m in pattern.finditer(md_block):
        cap_id = m.group(1).strip()
        cap_name = m.group(2).strip()
        tbl = m.group(3)
        lines = [ln.strip() for ln in tbl.strip().splitlines()]
        # remove alignment row (---)
        hdr = [c.strip() for c in lines[0].strip("| ").split("|")]
        data_lines = []
        for ln in lines[2:]:  # skip header and separator
            if ln.startswith("|"):
                ln = ln[1:]
            if ln.endswith("|"):
                ln = ln[:-1]
            data_lines.append([c.strip() for c in ln.split("|")])
        tables.append((f"Table {cap_id}: {cap_name}", hdr, data_lines))
    return tables

def strip_md(md):
    # crude markdown to text
    txt = re.sub(r"\*\*(.*?)\*\*", r"\1", md)
    txt = re.sub(r"\*(.*?)\*", r"\1", txt)
    txt = re.sub(r"`(.*?)`", r"\1", txt)
    txt = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", txt)
    return txt

def add_table(slide, x, y, caption, headers, rows):
    cols = len(headers)
    rows_n = len(rows) + 1
    table_shape = slide.shapes.add_table(rows_n, cols, x, y, Inches(9.0), Inches(2.5))
    table = table_shape.table
    for j, h in enumerate(headers):
        table.cell(0, j).text = h
    for i, r in enumerate(rows, start=1):
        for j, cell in enumerate(r):
            table.cell(i, j).text = cell
    # Caption
    tx = slide.shapes.add_textbox(x, y - Inches(0.4), Inches(4.5), Inches(0.3))
    tf = tx.text_frame
    tf.text = caption
    tf.paragraphs[0].font.size = Pt(12)
    tf.paragraphs[0].font.italic = True

def add_footer(slide, text):
    tx = slide.shapes.add_textbox(Inches(0.3), Inches(6.8), Inches(9.0), Inches(0.3))
    tf = tx.text_frame
    tf.text = text
    tf.paragraphs[0].font.size = Pt(10)
    tf.paragraphs[0].font.color.rgb = RGBColor(120,120,120)

def build():
    if os.path.exists(TEMPLATE):
        prs = Presentation(TEMPLATE)
    else:
        prs = Presentation()
    md = load_md(MD)
    slides = split_slides(md)
    today = datetime.date.today().isoformat()
    for num, subtitle, body in slides:
        layout = prs.slide_layouts[1] if len(prs.slide_layouts) > 1 else prs.slide_layouts[0]
        s = prs.slides.add_slide(layout)
        # Title
        title_shape = s.shapes.title
        if title_shape is None:
            title_shape = s.shapes.add_textbox(Inches(0.5), Inches(0.4), Inches(9), Inches(1)).text_frame
        else:
            title_shape = title_shape.text_frame
        title_shape.clear()
        p = title_shape.paragraphs[0]
        p.text = strip_md(f"{num}. {subtitle}")
        p.font.size = Pt(36)
        # Body
        body_shape = None
        for shp in s.shapes:
            if hasattr(shp, "text_frame") and shp != s.shapes.title:
                body_shape = shp
                break
        if body_shape is None:
            body_shape = s.shapes.add_textbox(Inches(0.5), Inches(1.5), Inches(9), Inches(5))
        tf = body_shape.text_frame
        tf.clear()
        # Extract bullets (lines starting with - or *)
        lines = [ln for ln in body.splitlines()]
        bullets = []
        for ln in lines:
            if re.match(r"^\s*-\s+", ln):
                bullets.append(strip_md(re.sub(r"^\s*-\s+", "", ln)))
        if bullets:
            for i, b in enumerate(bullets):
                if i == 0:
                    p = tf.paragraphs[0]
                else:
                    p = tf.add_paragraph()
                p.text = b
                p.level = 0
        else:
            tf.paragraphs[0].text = ""
        # Tables
        tables = md_tables(body)
        y = Inches(3.0)
        for cap, hdr, rows in tables:
            add_table(s, Inches(0.5), y, cap, hdr, rows)
            y += Inches(3.0)
        # Footer
        add_footer(s, f"Project: Cryoplant | Version: R1C2 | Date: {today} | Ref MD: slides/Slides.md")
    prs.save(OUT)
    print(f"Wrote {OUT}")

if __name__ == "__main__":
    build()
